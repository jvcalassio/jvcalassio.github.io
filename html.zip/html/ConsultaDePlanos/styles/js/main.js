
$(document).ready(function() {
    $('#input-condo').autoComplete({
        minLength: 1
    });


    $('.bloco-item').click(function() {
        let val = $(this).data('id');
        $('#input-bloco-value').val(val);
        $('#main-form').submit();
    });

    $('#input-condo').on('autocomplete.select', function(e, item) { 
        $("#input-condo-value").val(item.value);
    });
});