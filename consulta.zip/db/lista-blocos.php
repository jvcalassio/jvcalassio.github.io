<?php
error_reporting(0);
require("conn.php");
header('Content-type: application/json');

$id_condo = $_GET['condo'];

if(isset($id_condo)) {
    $statement = $conn->prepare("SELECT id, nome FROM bloco WHERE idPredio = :id ORDER BY nome");
    $statement->bindParam(":id", $id_condo);
} else {
    $statement = $conn->prepare("SELECT id, nome FROM bloco ORDER BY nome");
}
$statement->execute();

$rows = $statement->fetchAll();

$res = array();

foreach($rows as $row) {    
    $mini_res = array();
    $mini_res['value'] = intval($row['id']);
    $mini_res['text'] = $row['nome'];

    array_push($res, $mini_res);
}

echo json_encode($res, JSON_PRETTY_PRINT);

?>