<?php   

$predio = mb_strtoupper($_POST['predio']);
$bloco = mb_strtoupper($_POST['bloco']);
$problema = $_POST['problema'];
$observacao = mb_strtoupper($_POST['observacao']);

$logfile_dir = "/var/log/intervip/";   // or "/var/log/" for Linux
$logfile = $logfile_dir . "enviar-email.log";

$email_para = "ptc@intervip.net.br" ;
$email_cc1 = "noc@intervip.net.br" ;

$email_cc2 = "atendimento@intervip.net.br" ;

#Pegando usuario logado via apache
$user_exec = $_SERVER['PHP_AUTH_USER'];

// Inclui o arquivo class.phpmailer.php localizado na mesma pasta do arquivo php 
include "PHPMailer-master/PHPMailerAutoload.php"; 
 
// Inicia a classe PHPMailer 
$mail = new PHPMailer(); 
 
// Método de envio 
$mail->IsSMTP(); 
 
// Enviar por SMTP 
$mail->Host = "smtp.gmail.com"; 
 
// Você pode alterar este parametro para o endereço de SMTP do seu provedor 
$mail->Port = 587; 
 
 
// Usar autenticação SMTP (obrigatório) 
$mail->SMTPAuth = true; 

if(empty($bloco)) {
	$bloco = "N/A";
}

switch ($problema) {
	case 'dhcp':

		$desc_problema = "DHCP na Rede";

		break;

	case 'loop':
		
		$desc_problema = "LOOP na Rede";

		break;
	
	case 'link_lan':
		
		// Envia tb pro atendimento
		$mail->AddCC($email_cc2, 'CRI');
		$desc_problema = "Sem Link na LAN";

		break;


	case 'offline':

		// Envia tb pro atendimento
		$mail->AddCC($email_cc2, 'CRI');
		$desc_problema = "PREDIO FORA DO AR";

		break;

	case 'aviso':
		
		// Envia tb pro atendimento
		$mail->AddCC($email_cc2, 'CRI'); 

		$desc_problema = "AVISO";

		break;

	case 'predio_sem_projeto':
		
		$desc_problema = "PREDIO SEM PROJETO";

		break;

	case 'visada_ruim':
		
		$desc_problema = "REFAZER VISADA DO RÁDIO";

		break;

	default:

		$desc_problema = "ERRO PARA DEFINIR PROBLEMA";
		break;
}

// Usuário do servidor SMTP (endereço de email) 
// obs: Use a mesma senha da sua conta de email 
$mail->Username = 'site@intervip.net.br'; 
$mail->Password = 'os7gooPh'; 
 
// Configurações de compatibilidade para autenticação em TLS 
$mail->SMTPOptions = array( 'ssl' => array( 'verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true ) ); 
 
// Você pode habilitar esta opção caso tenha problemas. Assim pode identificar mensagens de erro. 
// $mail->SMTPDebug = 2; 
 
// Define o remetente 
// Seu e-mail 
$mail->From = "noc@intervip.net.br"; 
 
// Seu nome 
$mail->FromName = "NOC - INTERVIP"; 
 
// Define o(s) destinatário(s) 
//$mail->AddAddress('muller.muraro@intervip.net.br', 'Muller'); 
$mail->AddAddress($email_para, 'Logistica');

// Opcional: mais de um destinatário
// $mail->AddAddress('fernando@email.com'); 

// Opcionais: CC e BCC
	//$mail->AddCC('muller@intervip.net.br', 'NOC'); 
//$mail->AddCC($email_cc1, 'NOC'); 
	// $mail->AddBCC('roberto@gmail.com', 'Roberto'); 

// Definir se o e-mail é em formato HTML ou texto plano 
// Formato HTML . Use "false" para enviar em formato texto simples ou "true" para HTML.
$mail->IsHTML(true); 
 
// Charset (opcional) 
$mail->CharSet = 'UTF-8'; 
 
// Assunto da mensagem 
$mail->Subject = '[NOC] '.$desc_problema.' --> '.$predio.' - '.date("d/m/Y");
 
// Corpo do email 
$mail->Body = 	'PREDIO: '.$predio.'<br>'.
				'BLOCO: '.$bloco.'<br>'.
				'PROBLEMA: '.$desc_problema.'<br>'.
				'OBSERVAÇÃO: '.$observacao.'<br>'.
				'OPERADOR: '.$user_exec;
 
// Opcional: Anexos 
// $mail->AddAttachment("/home/usuario/public_html/documento.pdf", "documento.pdf"); 
 
// Envia o e-mail 
$enviado = $mail->Send(); 
 
// Exibe uma mensagem de resultado 
if ($enviado) 
{ 

	// Gera log
    file_put_contents($logfile, "----------------INICIO----------------\n".date("Y-m-d H:i:s")." Email enviado pelo usuario ".$user_exec." , Conteudo: \nPREDIO: $predio
BLOCO: $bloco
PROBLEMA: $desc_problema
OBSERVAÇÃO: $observacao
------------------FIM------------------\n" , FILE_APPEND);

    header('Location: sucesso.html');

} else { 

	// Gera log
	file_put_contents($logfile, "----------------INICIO----------------\n".date("Y-m-d H:i:s")." Email enviado pelo usuario ".$user_exec." , Conteudo: \nPREDIO: $predio
BLOCO: $bloco
PROBLEMA: $desc_problema
OBSERVAÇÃO: $observacao
------------------FIM------------------\n" , FILE_APPEND);

	header('Location: erro.html');
    //echo "Houve um erro enviando o email: ".$mail->ErrorInfo; 
} 
 
 
?>
