<?php
error_reporting(0);

function condo_selecionado() {
    global $conn;

    $condo_atual = $_GET['condo'];

    if(isset($condo_atual)) {
        $statement = $conn->prepare("SELECT id, nome FROM condominios WHERE id = :id");
        $statement->bindParam(":id", $condo_atual);
        $statement->execute();
    
        $row = $statement->fetch();
    
        echo "<script>".
            "$('#input-condo').autoComplete('set', {value: ".$row['id'].", text: \"". $row['nome'] ."\"});".
            "$('#input-condo-value').val(".$row['id'].");".
            "</script>";
    }

    $bloco_atual = $_GET['bloco'];

    if(isset($bloco_atual)) {
        $statement = $conn->prepare("SELECT id, nome FROM bloco WHERE id = :id");
        $statement->bindParam(":id", $bloco_atual);
        $statement->execute();
    
        $row = $statement->fetch();
    
        echo "<script>".
            "$('#input-bloco').autoComplete('set', {value: ".$row['id'].", text: \"". $row['nome'] ."\"});".
            "$('#input-bloco-value').val(".$row['id'].");".
            "</script>";
    }
}

function dados_condo() {
    global $conn;

    $condo_atual = $_GET['condo'];

    if(isset($condo_atual)) {
        $statement = $conn->prepare("SELECT
                                        condominios.id,
                                        cep.cep,
                                        cep.rua,
                                        cep.bairro,
                                        cep.cidade,
                                        condominios.numero
                                    FROM
                                        cep,
                                        condominios
                                    WHERE
                                        condominios.cep = cep.cep
                                    AND condominios.id = :id
                                    ");
        $statement->bindParam(":id", $condo_atual);
        $statement->execute();
    
        $row = $statement->fetch();
        return $row;
    }
}

function planos_condo() {
    
}

?>