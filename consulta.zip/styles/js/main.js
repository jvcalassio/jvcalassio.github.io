
$(document).ready(function() {
    $('#input-condo').autoComplete({
        minLength: 1
    });

    $('#input-bloco').autoComplete({
        minLength: 1
    });

    $('#input-condo').on('autocomplete.select', function(e, item) { 
        $("#input-condo-value").val(item.value);
    });

    $('#input-bloco').on('autocomplete.select', function(e, item) { 
        $("#input-bloco-value").val(item.value);
        $("#main-form").submit();
    });
});