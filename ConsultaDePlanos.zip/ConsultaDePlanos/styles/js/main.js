
$(document).ready(function() {
    $('#input-condo').autoComplete({
        minLength: 1
    });


    $('.bloco-item').click(function() {
        let val = $(this).data('id');
        $('#input-bloco-value').val(val);
        $('#main-form').submit();
    });

    $('#input-condo').on('autocomplete.select', function(e, item) { 
        $("#input-condo-value").val(item.value);
    });

    $('#copy-crb').click(function() {
        $('#crb').focus();
        $('#crb').select();
        document.execCommand("copy");
    });

    $('.unidade-item').click(function(e) {
        e.preventDefault();
        update_routerbox($(this).html());
        $('#selecionar_ap').modal('hide');
    });

    $('#numero_unidade').on('keyup', function() {
        update_routerbox($(this).val());
    });

    function update_routerbox(numero) {
        $('#crb').val(msg + numero);
    }
});