<?php

require("db/conn.php");
require("db/includes.php");

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
	<title>Consulta de Planos</title>
	
	<!-- CSS -->
	<link href="styles/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="styles/style.css">
	

</head>
<body class="geral">
	
	<top-header>
		<header>
			
			<div class="container-fluid"> 
				
				<div class="row">
					
					<div class="col-12 col-sm-2 col-md-3 logo-wrapper">
						<!-- <div class="logo"></div> -->
						<a href="./"><img class="logo" src="styles/assets/logo.png"></a>
					</div>
				
					<div class="col-12 col-sm-8 col-md-6" id="cabecalho">
						<h2>Consulta de Planos</h2>
					</div>
					<div class="col-12 col-sm-2 col-md-3">
						
					</div>
				
				</div>
			</div>

		</header>
	</top-header>
	
	<main >
		
		<div class="container-fluid">
			<!--<div class="row">
					
				<div class="col-12 col-sm-2 col-md-3">
					
				</div>-->
			
				<!--div class="col-12 col-sm-8 col-md-6 ColPrincipal" id="ColPrincipal"-->
				<div class="container">

					<form action="./" method="get" id="main-form">
					<div class="card border border-dark bg-light">
						<!--<img src="styles/assets/natureza4.jpeg" class="card-img-top">-->
						<div class="card-body">
								<div class="input-group">
									<label for="input-condo" class="form-label d-block w-100"><h3 class="card-title">Informe o prédio:</h3></label>
									<input type="text" class="form-control form-control-lg" id="input-condo" 
										placeholder="Insira o nome do condominio" autocomplete="off" data-url="./db/lista-condos.php">
									<input type="text" name="condo" class="d-none" id="input-condo-value">
									
									<div class="input-group-append">
										<button type="submit" class="btn btn-primary">Confirmar</button>
									</div>
								</div>
						</div>
						<section class="row">
							<div class="col-md-6">
								<h3 class="planos-title">Informações do condomínio</h3>
								<?php $dados = dados_condo(); ?>
								<table id="tbl-informacoes" class="table table-hover">
									<thead class="thead-dark">
										<tr>
											<th></th>
											<th></th>
										</tr>
									</thead>
									
									<tbody>
										<tr class="table-primary">
											<th scope="row">CEP:</td>
											<td><?php echo $dados['cep']; ?></td>
										</tr>
										<tr class="table-primary">
											<th scope="row">Endereço:</td>
											<td><?php echo $dados['rua']; ?></td>
										</tr>
										<tr class="table-primary">
											<th scope="row">Número:</td>
											<td><?php echo $dados['numero']; ?></td>
										</tr>
										<tr class="table-primary">
											<th scope="row">Cidade:</td>
											<td><?php echo $dados['cidade']; ?></td>
										</tr>
										<tr class="table-primary">
											<th scope="row">Bairro:</td>
											<td><?php echo $dados['bairro']; ?></td>
										</tr>
										<tr class="table-primary">
											<th scope="row">Bloco/Torre:</td>
											<td style="position: relative;">
												<?php if($dados['id'] != null): ?>
												
												<div class="dropdown show">
													<?php $blocos = lista_blocos_condo($dados['id']); ?>
													<a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdown-blocos" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														<?php $bi = 0; foreach($blocos as $row) : if(isset($_GET['bloco']) && $row['id'] == $_GET['bloco']): ?>
															<?php echo $row['nome']; $bi++; ?>
														<?php endif; endforeach;
															if($bi == 0) echo "Selecione o bloco/torre";
														?>
													</a>
													<div class="dropdown-menu" aria-labelledby="dropdown-blocos">
														<?php foreach($blocos as $row) : ?>
															<a class="dropdown-item bloco-item" href="#" data-id="<?php echo $row['id']; ?>"><?php echo $row['nome']; ?></a>
														<?php endforeach; ?>
													</div>
												</div>
												<input type="text" name="bloco" id="input-bloco-value" class="d-none">
												<?php endif; ?>
											</td>
										</tr>
									</tbody>
		
									<thead class="thead-dark">
										<tr>
											<th></th>
											<th></th>
										</tr>
									</thead>
								</table>
							</div>
							<div class="col-md-6">
								<h3 class="planos-title">Planos Disponíveis</h3>
								<?php $planos = planos_condo(); ?>
								<table id="tbl-planos" class="table table-hover">
									<thead class="thead-dark">
										
										<tr>
											<th>Estrutura do Prédio:</th>
											<th><?php echo $planos[0]['tecnologia'];?></th>
										</tr>
									</thead>
									<tbody>
										<tr class="fundo-cinza">
											<th>Tipo</th>
											<th>Valor (R$)</th>
										</tr>

										<?php foreach($planos as $plano) : ?>
										<tr>
											<td class="plano-tipo"><?php echo $plano['Descricao']; ?></td>
											<td>R$<?php echo str_replace('.', ',', $plano['Valor']); ?></td>
										</tr>
										<?php endforeach; ?>
									</tbody>
									<thead class="thead-dark">
										<tr>
											<th></th>
											<th></th>
										</tr>
									</thead>
								</table>
							</div>
						</section>
					</div>
					
				
					</form>
				</div>
				<!--div class="col-12 col-sm-2 col-md-3">
					
				</div>
			
			</div-->
		</div>
	</main>	
	<footer class="footer navbar-fixed-bottom">
	
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-2"><a href="./"><img class="logo" src="styles/assets/logo.png"></a></div>
			</div>
			<div class="row">
				<div class="col-md-10 d-flex align-items-center">
					<p>© 2021 Consulta de Planos | Todos os direitos reservados a Intervip.</p>
				</div>
			</div>
		</div>
	
	
		<!-- JS -->
		<script src="styles/js/jquery.js"></script>
		<script src="styles/js/bootstrap.bundle.min.js"></script>
		<script src="styles/js/bootstrap-autocomplete.min.js"></script>
		<script src="styles/js/main.js?v=1.0"></script>
		<?php condo_selecionado(); ?>
		
	</footer>
</body>




</html>
