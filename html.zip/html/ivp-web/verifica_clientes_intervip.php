<link href="main.css" media="all" rel="stylesheet" />
<?php
$matricula = $_POST["matricula"];
$acao = $_POST["acao"];

#Pegando usuario logado via apache
$user_exec = $_SERVER['PHP_AUTH_USER'];

if(empty($matricula )) {
	echo "<h2>O campo Matricula deve ser preenchido!</h2>\n" ;
	echo "Clique em <a href='$url'>Voltar</a> para tentar novamente";
die;
}

if($acao == "ALTERAR_VELOCIDADE"){
	$velocidade = $_POST['velocidade'];
}

function voltar()
{
   $url = htmlspecialchars($_SERVER['HTTP_REFERER']);
   echo "<br/><br/>";
   echo "<a href='$url'>Voltar</a>";
}

echo "<h2>Retorno da execucao do Script:</h2>";

switch ($acao) {
	case 'BLOQUEAR':

		echo "Operação não suportada nesta versão!";
		#$output = shell_exec("/var/vixnet/script/testa_user.sh -a \"$acao\" -m \"$matricula\"");
		break;

	case 'DESBLOQUEAR':
		
		echo "O desbloqueio dos clientes devera ser feito pelo Routerbox, na opção \"Informar Pagamento\"";
		#$output = shell_exec("sudo /var/vixnet/script/verifica_clientes_intervip.sh -a \"$acao\" -m \"$matricula\" --user-exec \"$user_exec\"   ");
		break;
	
	case 'LISTAR':

		#$output = shell_exec("bash -x /var/vixnet/script/verifica_clientes_intervip.sh -a \"$acao\" -m \"$matricula\"");
		$output = shell_exec("sudo /var/vixnet/script/verifica_clientes_intervip.sh -a \"$acao\" -m \"$matricula\" --user-exec \"$user_exec\"   ");
		break;

	case 'ALTERAR_VELOCIDADE':
	
		echo "Operação não suportada nesta versão!";
		#echo "/var/vixnet/script/testa_user.sh -a \"$acao\" -m \"$matricula\" -velocidade \"$velocidade\"";
		#$output = shell_exec("/var/vixnet/script/testa_user.sh -a \"$acao\" -m \"$matricula\"");
		break;

	default:

		echo "Opção Inválida!";
		# code...
		break;
}

echo "<pre>$output</pre>";

voltar();

?>